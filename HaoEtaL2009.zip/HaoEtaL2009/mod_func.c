#include <stdio.h>
#include "hocdec.h"
/* change name when structures in neuron.exe change*/
/* and also change the mos2nrn1.sh script */
int nocmodl5_5;

modl_reg(){
	nrn_mswindll_stdio(stdin, stdout, stderr);
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," ampa.mod");
fprintf(stderr," gabaa.mod");
fprintf(stderr," gabab.mod");
fprintf(stderr," h.mod");
fprintf(stderr," kadist.mod");
fprintf(stderr," kaprox.mod");
fprintf(stderr," kdrca1.mod");
fprintf(stderr," na3.mod");
fprintf(stderr," nax.mod");
fprintf(stderr," nmda.mod");
fprintf(stderr," shunting_factor.mod");
NOT_PARALLEL_SUB(fprintf(stderr, "\n");)
_ampa_reg();
_gabaa_reg();
_gabab_reg();
_h_reg();
_kadist_reg();
_kaprox_reg();
_kdrca1_reg();
_na3_reg();
_nax_reg();
_nmda_reg();
_shunting_factor_reg();
}
